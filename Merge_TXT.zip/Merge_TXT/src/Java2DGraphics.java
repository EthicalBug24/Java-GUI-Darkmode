import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;


public class Java2DGraphics {
    static int totalLine = 10;
    static int repetition = 4;
    static int configItemNum = 5;

    public static void main(String[] args) {
        System.out.println("test");
        mergeTXT("data_", configItemNum);
    }


    public static void mergeTXT(String file_prefix, int deletedRow){
        FileReader fileInput;
        BufferedReader bufferInput;

        String[] dataMerge = new String[totalLine+10];
        for(int z=0; z<dataMerge.length; z++){
            dataMerge[z]="";
        }

        try {
            for(int i=0; i<repetition; i++){
                String currentFile = file_prefix + (i+1) + ".txt";
                fileInput = new FileReader(currentFile);
                bufferInput = new BufferedReader(fileInput);

                String data = "Init";
                int lineNum = 0;

                while(data != null) {
                    data = bufferInput.readLine();
                    //System.out.println(data);

                    if(data!=null){
                        if(i==0){
                            dataMerge[lineNum] =  dataMerge[lineNum]+data+",";
                        }
                        else{
                            String[]dataSplit = data.split(",");
                            for(int x=deletedRow; x<dataSplit.length; x++){
                                dataMerge[lineNum] = dataMerge[lineNum]+dataSplit[x]+",";
                            }
                        }
                    }
                    System.out.println(dataMerge[lineNum]);

                    lineNum++;
                }


            }

            //generate TXT
            generateTXT(dataMerge);
        } 
        catch (Exception e){
            System.err.println("No output data");
            return;
        }
    }

    public static void generateTXT(String[] data){
        try {
            FileWriter fileOutput = new FileWriter("summary.txt",false);
            BufferedWriter bufferOutput = new BufferedWriter(fileOutput);

            for(int i=0; i<data.length; i++){
                bufferOutput.write(data[i]);
                bufferOutput.newLine();
            }
            bufferOutput.flush();

            bufferOutput.close();
        }
        catch (Exception e){
            System.err.println("No output data");
            return;
        }

    }
}

