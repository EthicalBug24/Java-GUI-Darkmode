package controller;

import javax.swing.*;
import java.awt.event.*;
import java.text.DecimalFormat;

import gui.mainWindow.*;
import gui.connectWindow.*;
import gui.loadingWindow.LoadingWindow;

import java.awt.*;

public class prnDumpController implements ActionListener{

    //OTHER CLASS
    MainWindow mainWindow = new MainWindow();
    ConnectWindow connectWindow = new ConnectWindow();
    LoadingWindow loadingWindow = new LoadingWindow();

    //WINDOW ATTRIBUTE DECLARATION
    public JPanel prnDumpPanel;

    //UI ATTRIBUTE DIMENSION AND LAYOUT
    //APPLI PANEL
    int prnDumpPanel_W = 430;
    int prnDumpPanel_H = 620;


    //CONSTRUCTOR
    public prnDumpController(){
        //APPLI PANEL DEFINE
        prnDumpPanel = new JPanel();
        prnDumpPanel.setLayout(null);
        prnDumpPanel.setBounds(0, 0, prnDumpPanel_W, prnDumpPanel_H);
        prnDumpPanel.setBackground(new Color(0,0,0,0));

        //APPLI PANEL ADD COMPONEN
        prnDumpPanel.add(loadingWindow.loadingMainPanel);
        prnDumpPanel.add(connectWindow.connectPanel);
        prnDumpPanel.add(connectWindow.disconnectPanel);
        prnDumpPanel.add(mainWindow.headerPanel);
        prnDumpPanel.add(mainWindow.mainPanel);

        //SET ACTION LISTENER
        connectWindow.connectButton.addActionListener(this);
        connectWindow.disconnectButton.addActionListener(this);
        mainWindow.startDumpButton.addActionListener(this);
        loadingWindow.pauseButton.addActionListener(this);
        loadingWindow.continueButton.addActionListener(this);
        loadingWindow.stopButton.addActionListener(this);
        
        
        //SET VISIBLE
        prnDumpPanel.setVisible(true);
        loadingWindow.loadingMainPanel.setVisible(false);;
    }

    @Override
    public void actionPerformed(ActionEvent e){

        if(e.getSource() == connectWindow.connectButton){
            connectWindow.connectPanel.setVisible(false);
            connectWindow.disconnectPanel.setVisible(true);
        }

        if(e.getSource() == connectWindow.disconnectButton){
            connectWindow.connectPanel.setVisible(true);
            connectWindow.disconnectPanel.setVisible(false);
        }

        if(e.getSource() == mainWindow.startDumpButton){
            mainWindow.headerPanel.setBackground(Color.decode(mainWindow.color_darkMode_2));
            mainWindow.mainPanel.setVisible(false);
            connectWindow.connectPanel.setVisible(false);
            connectWindow.disconnectPanel.setVisible(false);
            loadingWindow.loadingMainPanel.setVisible(true);

            Thread progressThread = new Thread(() -> {
                progressSimulation();
            });   

            Thread dumpSpeedThread = new Thread(() -> {
                dumpSpeedSimulation();
            });   

            Thread dumpedDataThread = new Thread(() -> {
                dumpedDataSimulation();
            });   

            Thread timeRemainThread = new Thread(() -> {
                timeRemainSimulation();
            });   

            progressThread.start();
            dumpSpeedThread.start();
            dumpedDataThread.start();
            timeRemainThread.start();

            
        }

        if(e.getSource() == loadingWindow.pauseButton){
            loadingWindow.pausePanel.setVisible(false);
            loadingWindow.continuePanel.setVisible(true);
        }

        if(e.getSource() == loadingWindow.continueButton){
            loadingWindow.pausePanel.setVisible(true);
            loadingWindow.continuePanel.setVisible(false);
        }
        
    }

    void progressSimulation() {
        int i = 0;
        int j = 0;
        double progress = 0;
        loadingWindow.progressNumLabel.setText(Integer.toString(i) + "%");
        loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_0_Icon);


        for (i = 0; i<=100; i++){

            progress = i * 1;

            //loadingWindow.progressNumLabel.setText(Double.toString(progress)+ "%");
            loadingWindow.progressNumLabel.setText((new DecimalFormat("##").format(progress))  +  "%");


            if(i%5 == 0){
                j++;
                System.out.println("J : " + j);

                if      (j == 2){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_1_Icon);}
                else if (j == 3){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_2_Icon);}
                else if (j == 4){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_3_Icon);}
                else if (j == 5){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_4_Icon);}
                else if (j == 6){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_5_Icon);}
                else if (j == 7){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_6_Icon);}
                else if (j == 8){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_7_Icon);}
                else if (j == 9){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_8_Icon);}
                else if (j == 10){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_9_Icon);}
                else if (j == 11){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_10_Icon);}
                else if (j == 12){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_11_Icon);}
                else if (j == 13){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_12_Icon);}
                else if (j == 14){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_13_Icon);}
                else if (j == 15){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_14_Icon);}
                else if (j == 16){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_15_Icon);}
                else if (j == 17){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_16_Icon);}
                else if (j == 18){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_17_Icon);}
                else if (j == 19){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_18_Icon);}
                else if (j == 20){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_19_Icon);}
                else if (j == 21){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_20_Icon);
                //else if (j == 22){loadingWindow.progressBarLabel.setIcon(loadingWindow.Progress_0_Icon);
                    try{
                        Thread.sleep(5000);
        
                    }catch(Exception e ){}}

            }

            try{
                Thread.sleep(100);

            }catch(Exception e ){}

        }

        // mainWindow.mainPanel.setVisible(true);
        // connectWindow.connectPanel.setVisible(true);
        // connectWindow.disconnectPanel.setVisible(true);
        // loadingWindow.loadingMainPanel.setVisible(false);
    }

    void dumpSpeedSimulation() {
        int i = 0;
        int j = 0;
        float speed = 0;
        loadingWindow.dumpSpeedNumLabel.setText(Float.toString(speed));
        loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_0_Icon);


        for (i = 0; i<200; i++){
            speed = speed + (float)0.15; 

            //loadingWindow.dumpSpeedNumLabel.setText(Float.toString(speed));
            loadingWindow.dumpSpeedNumLabel.setText(new DecimalFormat("##.###").format(speed));

            if(i%12 == 0){
               j++;
               System.out.println("J2 : " + j);

               if      (j == 2) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_1_Icon);}
               else if (j == 3) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_2_Icon);}
               else if (j == 4) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_3_Icon);}
               else if (j == 5) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_4_Icon);}
               else if (j == 6) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_5_Icon);}
               else if (j == 7) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_6_Icon);}
               else if (j == 8) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_7_Icon);}
               else if (j == 9) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_8_Icon);}
               else if (j == 10){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_9_Icon);}
               else if (j == 11){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_10_Icon);}
               else if (j == 12){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_11_Icon);}
               else if (j == 13){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_12_Icon);}
               else if (j == 14){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_13_Icon);}
               else if (j == 15){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_14_Icon);}
               else if (j == 16){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_15_Icon);}
               else if (j == 17){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_16_Icon);}
            }

            try{
                Thread.sleep(50);

            }catch(Exception e ){}

        }

        for (i = 200; i>0; i--){
            speed = speed - (float)0.15; 

            //loadingWindow.dumpSpeedNumLabel.setText(Float.toString(speed));
            loadingWindow.dumpSpeedNumLabel.setText(new DecimalFormat("##.###").format(speed));

            if(i%12 == 0){
               j--;
               System.out.println("J2 : " + j);

               if      (j == 1) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_0_Icon);}
               else if (j == 2) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_1_Icon);}
               else if (j == 3) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_2_Icon);}
               else if (j == 4) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_3_Icon);}
               else if (j == 5) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_4_Icon);}
               else if (j == 6) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_5_Icon);}
               else if (j == 7) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_6_Icon);}
               else if (j == 8) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_7_Icon);}
               else if (j == 9) {loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_8_Icon);}
               else if (j == 10){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_9_Icon);}
               else if (j == 11){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_10_Icon);}
               else if (j == 12){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_11_Icon);}
               else if (j == 13){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_12_Icon);}
               else if (j == 14){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_13_Icon);}
               else if (j == 15){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_14_Icon);}
               else if (j == 16){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_15_Icon);}
               else if (j == 17){loadingWindow.dumpSpeedBarLabel.setIcon(loadingWindow.dumpSpeed_16_Icon);}
            }

            try{
                Thread.sleep(50);

            }catch(Exception e ){}

        }
    }



    void dumpedDataSimulation() {
        int i = 0;
        int j = 0;
        int dumpedData = 0;
        int totalSize = 40750;
        loadingWindow.dumpedNumLabel.setText(Integer.toString(dumpedData));
        loadingWindow.totalSizeLabel.setText(Integer.toString(totalSize));
        loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_0_Icon);


        for (i = 0; i<totalSize; i++){
            
            dumpedData ++ ;
            
            loadingWindow.dumpedNumLabel.setText(Integer.toString(dumpedData));

            if(i%2546 == 0){
               j++;
               System.out.println("J3 : " + j);

               if      (j == 2) {loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_1_Icon);}
               else if (j == 3) {loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_2_Icon);}
               else if (j == 4) {loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_3_Icon);}
               else if (j == 5) {loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_4_Icon);}
               else if (j == 6) {loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_5_Icon);}
               else if (j == 7) {loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_6_Icon);}
               else if (j == 8) {loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_7_Icon);}
               else if (j == 9) {loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_8_Icon);}
               else if (j == 10){loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_9_Icon);}
               else if (j == 11){loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_10_Icon);}
               else if (j == 12){loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_11_Icon);}
               else if (j == 13){loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_12_Icon);}
               else if (j == 14){loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_13_Icon);}
               else if (j == 15){loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_14_Icon);}
               else if (j == 16){loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_15_Icon);}
               else if (j == 17){loadingWindow.dumpedBarLabel.setIcon(loadingWindow.dumpedData_16_Icon);}
            }

            try{
                Thread.sleep(1);

            }catch(Exception e ){}
        }

    }

    void timeRemainSimulation() {
        int i = 0;
        int j = 0;
        int totalTime = 68;
        String unit = "Second";
        int timeRemain = totalTime;

        loadingWindow.timeRemainNumLabel.setText(Integer.toString(timeRemain) + " " + unit);
        loadingWindow.timeUnitLabel.setText(unit);
        loadingWindow.totalTimeLabel.setText(Integer.toString(totalTime));
        loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_0_Icon);


        for (i = 0; i<totalTime; i++){
            
            timeRemain -- ;
            
            loadingWindow.timeRemainNumLabel.setText(Integer.toString(timeRemain));

            if(timeRemain%4 == 0){
               j++;
               System.out.println("J4 : " + j);

               if      (j == 2) {loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_1_Icon);}
               else if (j == 3) {loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_2_Icon);}
               else if (j == 4) {loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_3_Icon);}
               else if (j == 5) {loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_4_Icon);}
               else if (j == 6) {loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_5_Icon);}
               else if (j == 7) {loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_6_Icon);}
               else if (j == 8) {loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_7_Icon);}
               else if (j == 9) {loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_8_Icon);}
               else if (j == 10){loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_9_Icon);}
               else if (j == 11){loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_10_Icon);}
               else if (j == 12){loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_11_Icon);}
               else if (j == 13){loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_12_Icon);}
               else if (j == 14){loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_13_Icon);}
               else if (j == 15){loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_14_Icon);}
               else if (j == 16){loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_15_Icon);}
               else if (j == 17){loadingWindow.timeRemainBarLabel.setIcon(loadingWindow.timeRemain_16_Icon);}
            }

            try{
                Thread.sleep(500);

            }catch(Exception e ){}
        }

    }
}
