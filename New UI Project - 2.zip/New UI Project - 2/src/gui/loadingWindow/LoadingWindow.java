package gui.loadingWindow;

import javax.swing.*;
import java.awt.*;

public class LoadingWindow {

    //WINDOW ATTRIBUTE DECLARATION
    public JPanel loadingMainPanel, pausePanel, continuePanel;
    //public JButton menuButton, prnDumpButton, rgbDumpButton, codecDump_1_Button, codecDump_2_Button, customDumpButton;
    public JButton pauseButton, continueButton, stopButton;
    public JLabel backgroundLabel;
    public JLabel pleaseWaitLabel;
    public JLabel progressBarLabel, progressNumLabel, progressLabel, progressUnderlineLabel ;
    public JLabel dumpSpeedBarLabel, dumpSpeedNumLabel, dumpSpeedLabel, dumpSpeedMaxLabel, dumpSpeedUnitLabel ;
    public JLabel dumpedBarLabel, dumpedNumLabel, dumpedUnitLabel, dumped0Label, totalSizeLabel, dumpedLabel ;
    public JLabel timeRemainBarLabel, timeRemainNumLabel, totalTimeLabel, time0Label, timeUnitLabel, timeRemainLabel ;
    public JLabel barTopLabel, barBottomLabel;
    public JTextArea infoTextArea;


    //UI ATTRIBUTE DIMENSION AND LAYOUT

    //MENU TOP PANEL;
    int loadingMainPanel_W = 420;
    int loadingMainPanel_H = 530;
    int loadingMainPanel_Left = 0;
    int loadingMainPanel_Top = 70;

    //PAUSE PANEL
    int pausePanel_W = loadingMainPanel_W/2;
    int pausePanel_H = 70;
    int pausePanel_Top = 450;
    int pausepanel_Left = 0;

    // //CONTINUE PANEL
    // int continuePanel_W = loadingMainPanel_W;
    // int continuePanel_H = pausePanel_H;
    // int continuePanel_Top = pausePanel_Top;
    // int continuepanel_Left = pausepanel_Left;

    // BACKGROUND LABEL;
    int backgroundLabel_W = 420;
    int backgroundLabel_H = 530;
    int backgroundLabel_Left = 0;
    int backgroundLabel_Top = 0;

    //PLEASE WAIT LABEL;
    int pleaseWaitLabel_W = 220;
    int pleaseWaitLabel_H = 30;
    int pleaseWaitLabel_Left = (loadingMainPanel_W/2) - (pleaseWaitLabel_W/2);
    int pleaseWaitLabel_Top = 3;

    //PROGRESS BAR LABEL;
    int progressBarLabel_W = 192;
    int progressBarLabel_H = 192;
    int progressBarLabel_Left = (loadingMainPanel_W/2) - 163;
    int progressBarLabel_Top = pleaseWaitLabel_Top + pleaseWaitLabel_H + 10;

    //PROGRESS NUM LABEL;
    int progressNumLabel_W = progressBarLabel_W;
    int progressNumLabel_H = progressBarLabel_H;
    int progressNumLabel_Left = progressBarLabel_Left;
    int progressNumLabel_Top = progressBarLabel_Top;

    //PROGRESS LABEL;
    int progressLabel_W = 220;
    int progressLabel_H = 30;
    int progressLabel_Left = progressBarLabel_Left - 10;
    int progressLabel_Top = progressNumLabel_Top + progressNumLabel_H - 5;

    //PROGRESS UNDERLINE;
    int progressUnderlineLabel_W = progressBarLabel_W;
    int progressUnderlineLabel_H = 20;
    int progressUnderlineLabel_Left = 0;
    int progressUnderlineLabel_Top = progressLabel_Top + progressLabel_H + 5;

    //DUMP SPEED BAR LABEL;
    int dumpSpeedBarLabel_W = 94;
    int dumpSpeedBarLabel_H = 104;
    int dumpSpeedBarLabel_Left = (loadingMainPanel_W/2) - (dumpSpeedBarLabel_W/2) - 2;
    int dumpSpeedBarLabel_Top = progressLabel_Top + progressLabel_H + 20;

    //DUMP SPEED NUM LABEL;
    int dumpSpeedNumLabel_W = 94;
    int dumpSpeedNumLabel_H = 74;
    int dumpSpeedNumLabel_Left = dumpSpeedBarLabel_Left;
    int dumpSpeedNumLabel_Top = dumpSpeedBarLabel_Top;

    //DUMP SPEED NUM LABEL;
    int dumpSpeedUnitLabel_W = 94;
    int dumpSpeedUnitLabel_H = 74;
    int dumpSpeedUnitLabel_Left = dumpSpeedBarLabel_Left;
    int dumpSpeedUnitLabel_Top = dumpSpeedBarLabel_Top + 23;

    //DUMP SPEED MAX LABEL;
    int dumpSpeedMaxLabel_W = 94;
    int dumpSpeedMaxLabel_H = 74;
    int dumpSpeedMaxLabel_Left = dumpSpeedBarLabel_Left;
    int dumpSpeedMaxLabel_Top = dumpSpeedBarLabel_Top + 60;

     
    //DUMPED DATA BAR LABEL;
    int dumpedBarLabel_W = dumpSpeedBarLabel_W;
    int dumpedBarLabel_H = dumpSpeedBarLabel_H;
    int dumpedBarLabel_Left = dumpSpeedBarLabel_Left - dumpedBarLabel_W - 35;
    int dumpedBarLabel_Top = dumpSpeedBarLabel_Top;

    //DUMPED DATA NUM LABEL;
    int dumpedNumLabel_W = dumpSpeedNumLabel_W;
    int dumpedNumLabel_H = dumpSpeedNumLabel_H;
    int dumpedNumLabel_Left = dumpedBarLabel_Left;
    int dumpedNumLabel_Top = dumpedBarLabel_Top + 12;

    //DUMPED UNIT LABEL;
    int dumpedUnitLabel_W = dumpSpeedNumLabel_W;
    int dumpedUnitLabel_H = dumpSpeedNumLabel_H;
    int dumpedUnitLabel_Left = dumpedBarLabel_Left;
    int dumpedUnitLabel_Top = dumpedNumLabel_Top + 15;

    //DUMPED 0 LABEL;
    int dumped0Label_W = dumpSpeedMaxLabel_W;
    int dumped0Label_H = dumpSpeedMaxLabel_H;
    int dumped0Label_Left = 7;
    int dumped0Label_Top = dumpSpeedMaxLabel_Top;

    //TOTAL DATA SIZE LABEL;
    int totalSizeLabel_W = dumpSpeedMaxLabel_W;
    int totalSizeLabel_H = dumpSpeedMaxLabel_H;
    int totalSizeLabel_Left = 53;
    int totalSizeLabel_Top = dumpSpeedMaxLabel_Top;


    //TIME REMAIN BAR LABEL;
    int timeRemainBarLabel_W = dumpSpeedBarLabel_W;
    int timeRemainBarLabel_H = dumpSpeedBarLabel_H;
    int timeRemainBarLabel_Left = dumpSpeedBarLabel_Left + dumpedBarLabel_W + 35;
    int timeRemainBarLabel_Top = dumpSpeedBarLabel_Top;


    //TIME REMAIN NUM LABEL;
    int timeRemainNumLabel_W = dumpSpeedNumLabel_W;
    int timeRemainNumLabel_H = dumpSpeedNumLabel_H;
    int timeRemainNumLabel_Left = timeRemainBarLabel_Left;
    int timeRemainNumLabel_Top = timeRemainBarLabel_Top;


    //TIME UNIT LABEL;
    int timeUnitLabel_W = dumpSpeedNumLabel_W;
    int timeUnitLabel_H = dumpSpeedNumLabel_H;
    int timeUnitLabel_Left = timeRemainBarLabel_Left;
    int timeUnitLabel_Top = dumpSpeedUnitLabel_Top;

    //TOTAL TIME LABEL;
    int time0Label_W = dumpSpeedNumLabel_W;
    int time0Label_H = dumpSpeedNumLabel_H;
    int time0Label_Left = timeRemainBarLabel_Left + 25;
    int time0Label_Top = dumpSpeedMaxLabel_Top;

    //TOTAL TIME LABEL;
    int totaltimeLabel_W = dumpSpeedNumLabel_W;
    int totaltimeLabel_H = dumpSpeedNumLabel_H;
    int totaltimeLabel_Left = timeRemainBarLabel_Left - 25;
    int totaltimeLabel_Top = dumpSpeedMaxLabel_Top;


    //BAR TOP NAME LABEL;
    int barTopLabel_W = loadingMainPanel_W;
    int barTopLabel_H = 20;
    int barTopLabel_Left = 0;
    int barTopLabel_Top = dumpSpeedBarLabel_Top + dumpSpeedNumLabel_H + 40;

    //BAR BOTTOM NAME LABEL;
    int barBottomLabel_W = loadingMainPanel_W;
    int barBottomLabel_H = barTopLabel_H;
    int barBottomLabel_Left = barTopLabel_Left;
    int barBottomLabel_Top = barTopLabel_Top + 20 ;


    //INFO TEXT AREA;
    int infoTextArea_W = 119;
    int infoTextArea_H = 224;
    int infoTextArea_Left = 278;
    int infoTextArea_Top = 36 ;


    //PAUSE BUTTON
    int pauseButton_W = 110;
    int pauseButton_H = 32;
    int pauseButton_Left = 90;
    int pauseButton_Top = 15;

    //STOP BUTTON
    int stopButton_W = pauseButton_W;
    int stopButton_H = pauseButton_H;
    int stopButton_Left = pauseButton_Left + pauseButton_W + 15;
    int stopButton_Top = pausePanel_Top + pauseButton_Top;


    //COLOR DEFINITION
    String color_darkMode_1     = "#23242C";
    String color_darkMode_2     = "#383B4F";
    String color_darkMode_3     = "#242633";
    String color_White_1        = "#F1F3F4";
    String color_greenBlue_1    = "#03DAC5";
    String color_magenta_1      = "#FF4A84";

    //FONT DEFINITION
    Font myFont = new Font("Verdana",Font.PLAIN, 16);
    Font myFont2 = new Font("Verdana",Font.PLAIN, 12);
    Font myFont3 = new Font("Verdana",Font.PLAIN, 14);
    Font myFont4 = new Font("Verdana",Font.PLAIN, 10);
    Font myFont5 = new Font("Verdana",Font.BOLD, 32);


    //GET CURRENT DIRECTORY
    String cwDir = System.getProperty("user.dir");

    //ICON DEFINITION
    public Icon background_Icon = new ImageIcon(cwDir  + "\\lib\\gui\\loadingWindow\\icon\\background\\LoadingBackground.png");

    public Icon Progress_0_Icon = new ImageIcon(cwDir  + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_0.png");
    public Icon Progress_1_Icon = new ImageIcon(cwDir  + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_1.png");
    public Icon Progress_2_Icon = new ImageIcon(cwDir  + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_2.png");
    public Icon Progress_3_Icon = new ImageIcon(cwDir  + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_3.png");
    public Icon Progress_4_Icon = new ImageIcon(cwDir  + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_4.png");
    public Icon Progress_5_Icon = new ImageIcon(cwDir  + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_5.png");
    public Icon Progress_6_Icon = new ImageIcon(cwDir  + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_6.png");
    public Icon Progress_7_Icon = new ImageIcon(cwDir  + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_7.png");
    public Icon Progress_8_Icon = new ImageIcon(cwDir  + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_8.png");
    public Icon Progress_9_Icon = new ImageIcon(cwDir  + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_9.png");
    public Icon Progress_10_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_10.png");
    public Icon Progress_11_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_11.png");
    public Icon Progress_12_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_12.png");
    public Icon Progress_13_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_13.png");
    public Icon Progress_14_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_14.png");
    public Icon Progress_15_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_15.png");
    public Icon Progress_16_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_16.png");
    public Icon Progress_17_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_17.png");
    public Icon Progress_18_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_18.png");
    public Icon Progress_19_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_19.png");
    public Icon Progress_20_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\progressBar6\\progressBar_20.png");


    public Icon dumpSpeed_0_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_0.png");
    public Icon dumpSpeed_1_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_1.png");
    public Icon dumpSpeed_2_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_2.png");
    public Icon dumpSpeed_3_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_3.png");
    public Icon dumpSpeed_4_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_4.png");
    public Icon dumpSpeed_5_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_5.png");
    public Icon dumpSpeed_6_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_6.png");
    public Icon dumpSpeed_7_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_7.png");
    public Icon dumpSpeed_8_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_8.png");
    public Icon dumpSpeed_9_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_9.png");
    public Icon dumpSpeed_10_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_10.png");
    public Icon dumpSpeed_11_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_11.png");
    public Icon dumpSpeed_12_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_12.png");
    public Icon dumpSpeed_13_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_13.png");
    public Icon dumpSpeed_14_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_14.png");
    public Icon dumpSpeed_15_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_15.png");
    public Icon dumpSpeed_16_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_16.png");


    public Icon dumpedData_0_Icon  = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_0.png");
    public Icon dumpedData_1_Icon  = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_1.png");
    public Icon dumpedData_2_Icon  = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_2.png");
    public Icon dumpedData_3_Icon  = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_3.png");
    public Icon dumpedData_4_Icon  = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_4.png");
    public Icon dumpedData_5_Icon  = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_5.png");
    public Icon dumpedData_6_Icon  = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_6.png");
    public Icon dumpedData_7_Icon  = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_7.png");
    public Icon dumpedData_8_Icon  = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_8.png");
    public Icon dumpedData_9_Icon  = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_9.png");
    public Icon dumpedData_10_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_10.png");
    public Icon dumpedData_11_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_11.png");
    public Icon dumpedData_12_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_12.png");
    public Icon dumpedData_13_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_13.png");
    public Icon dumpedData_14_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_14.png");
    public Icon dumpedData_15_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_15.png");
    public Icon dumpedData_16_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_16.png");


    public Icon timeRemain_0_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_0.png");
    public Icon timeRemain_1_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_1.png");
    public Icon timeRemain_2_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_2.png");
    public Icon timeRemain_3_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_3.png");
    public Icon timeRemain_4_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_4.png");
    public Icon timeRemain_5_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_5.png");
    public Icon timeRemain_6_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_6.png");
    public Icon timeRemain_7_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_7.png");
    public Icon timeRemain_8_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_8.png");
    public Icon timeRemain_9_Icon = new ImageIcon(cwDir +  "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_9.png");
    public Icon timeRemain_10_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_10.png");
    public Icon timeRemain_11_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_11.png");
    public Icon timeRemain_12_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_12.png");
    public Icon timeRemain_13_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_13.png");
    public Icon timeRemain_14_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_14.png");
    public Icon timeRemain_15_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_15.png");
    public Icon timeRemain_16_Icon = new ImageIcon(cwDir + "\\lib\\gui\\loadingWindow\\icon\\timeRemainBar3\\timeRemainBar_16.png");

    public Icon Progress_Underline_Icon = new ImageIcon(cwDir + "\\src\\gui\\loadingWindow\\icon\\Underline\\Underline0.png");

    public Icon pause_Button_Icon = new ImageIcon(cwDir + "\\src\\gui\\loadingWindow\\icon\\pausebutton\\pauseButton.png");
    public Icon pause_Button_Icon2 = new ImageIcon(cwDir + "\\src\\gui\\loadingWindow\\icon\\pausebutton\\pauseButton2.png");

    public Icon continue_Button_Icon = new ImageIcon(cwDir + "\\src\\gui\\loadingWindow\\icon\\continueButton\\continueButton.png");
    public Icon continue_Button_Icon2 = new ImageIcon(cwDir + "\\src\\gui\\loadingWindow\\icon\\continueButton\\continueButton2.png");

    public Icon stop_Button_Icon = new ImageIcon(cwDir + "\\src\\gui\\loadingWindow\\icon\\stopButton\\stopButton.png");
    public Icon stop_Button_Icon2 = new ImageIcon(cwDir + "\\src\\gui\\loadingWindow\\icon\\stopButton\\stopButton2.png");





    //CONSTRUCTOR
    public LoadingWindow(){

        //PANEL DEFINE
        loadingMainPanel = new JPanel();
        loadingMainPanel.setLayout(null);
        loadingMainPanel.setBounds(loadingMainPanel_Left, loadingMainPanel_Top, loadingMainPanel_W, loadingMainPanel_H);
        loadingMainPanel.setBackground(Color.decode(color_darkMode_2));

        pausePanel = new JPanel();
        pausePanel.setLayout(null);
        pausePanel.setBounds(pausepanel_Left, pausePanel_Top, pausePanel_W, pausePanel_H);
        pausePanel.setBackground(Color.decode(color_darkMode_3));

        continuePanel = new JPanel();
        continuePanel.setLayout(null);
        continuePanel.setBounds(pausepanel_Left, pausePanel_Top, pausePanel_W, pausePanel_H);
        continuePanel.setBackground(Color.decode(color_darkMode_3));

        //PROGRESS BAR LABEL DEFINE
        backgroundLabel = new JLabel(background_Icon);
        backgroundLabel.setLayout(null);
        backgroundLabel.setBounds(backgroundLabel_Left, backgroundLabel_Top, backgroundLabel_W, backgroundLabel_H);
        backgroundLabel.setBackground(new Color(0,0,0,0));

        //PLEASE WAIT LABEL DEFINE
        pleaseWaitLabel = new JLabel("Please Wait Dump in Progress");
        pleaseWaitLabel.setBounds(pleaseWaitLabel_Left, pleaseWaitLabel_Top, pleaseWaitLabel_W, pleaseWaitLabel_H);
        pleaseWaitLabel.setFont(myFont3);
        pleaseWaitLabel.setForeground(Color.decode(color_White_1));

        //PROGRESS BAR LABEL DEFINE
        progressBarLabel = new JLabel(Progress_0_Icon);
        progressBarLabel.setLayout(null);
        progressBarLabel.setBounds(progressBarLabel_Left, progressBarLabel_Top, progressBarLabel_W, progressBarLabel_H);
        progressBarLabel.setBackground(new Color(0,0,0,0));

        //PROGRESS NUM LABEL DEFINE
        progressNumLabel = new JLabel("0%", JLabel.CENTER);
        progressNumLabel.setBounds(progressNumLabel_Left, progressNumLabel_Top, progressNumLabel_W, progressNumLabel_H);
        progressNumLabel.setFont(myFont5);
        progressNumLabel.setForeground(Color.decode(color_White_1));

        //PROGRESS LABEL DEFINE
        progressLabel = new JLabel("Progress", JLabel.CENTER);
        progressLabel.setBounds(progressLabel_Left, progressLabel_Top, progressLabel_W, progressLabel_H);
        progressLabel.setFont(myFont3);
        progressLabel.setForeground(Color.decode(color_White_1));

        //PROGRESS UNDERLINE LABEL DEFINE
        progressUnderlineLabel = new JLabel(Progress_Underline_Icon);
        progressUnderlineLabel.setBounds(progressUnderlineLabel_Left, progressUnderlineLabel_Top, progressUnderlineLabel_W, progressUnderlineLabel_H);
        progressUnderlineLabel.setFont(myFont3);
        progressUnderlineLabel.setForeground(Color.decode(color_White_1));


        //DUMP SPEED BAR LABEL DEFINE
        dumpSpeedBarLabel = new JLabel(dumpSpeed_0_Icon);
        dumpSpeedBarLabel.setLayout(null);
        dumpSpeedBarLabel.setBounds(dumpSpeedBarLabel_Left, dumpSpeedBarLabel_Top, dumpSpeedBarLabel_W, dumpSpeedBarLabel_H);
        dumpSpeedBarLabel.setBackground(new Color(0,0,0,0));

        
        //DUMP SPEED NUM LABEL DEFINE
        dumpSpeedNumLabel = new JLabel("22.35", JLabel.CENTER);
        dumpSpeedNumLabel.setBounds(dumpSpeedNumLabel_Left, dumpSpeedNumLabel_Top, dumpSpeedNumLabel_W, dumpSpeedNumLabel_H);
        dumpSpeedNumLabel.setFont(myFont3);
        dumpSpeedNumLabel.setForeground(Color.decode(color_White_1));

        //DUMP SPEED UNIT LABEL DEFINE
        dumpSpeedUnitLabel = new JLabel("KB/S", JLabel.CENTER);
        dumpSpeedUnitLabel.setBounds(dumpSpeedUnitLabel_Left, dumpSpeedUnitLabel_Top, dumpSpeedUnitLabel_W, dumpSpeedUnitLabel_H);
        dumpSpeedUnitLabel.setFont(myFont3);
        dumpSpeedUnitLabel.setForeground(Color.decode(color_White_1));

        //DUMP SPEED NUM LABEL DEFINE
        dumpSpeedMaxLabel = new JLabel(" 0         30", JLabel.CENTER);
        dumpSpeedMaxLabel.setBounds(dumpSpeedMaxLabel_Left, dumpSpeedMaxLabel_Top, dumpSpeedMaxLabel_W, dumpSpeedMaxLabel_H);
        dumpSpeedMaxLabel.setFont(myFont2);
        dumpSpeedMaxLabel.setForeground(Color.decode(color_White_1));


        //DUMPED DATA BAR LABEL DEFINE
        dumpedBarLabel = new JLabel(dumpedData_0_Icon);
        dumpedBarLabel.setLayout(null);
        dumpedBarLabel.setBounds(dumpedBarLabel_Left, dumpedBarLabel_Top, dumpedBarLabel_W, dumpedBarLabel_H);
        dumpedBarLabel.setBackground(new Color(0,0,0,0));


        //DUMPED DATA NUM LABEL DEFINE
        dumpedNumLabel = new JLabel("1024000", JLabel.CENTER);
        dumpedNumLabel.setBounds(dumpedNumLabel_Left, dumpedNumLabel_Top, dumpedNumLabel_W, dumpedNumLabel_H);
        dumpedNumLabel.setFont(myFont4);
        dumpedNumLabel.setForeground(Color.decode(color_White_1));

        //DUMPED UNIT LABEL DEFINE
        dumpedUnitLabel = new JLabel("Byte", JLabel.CENTER);
        dumpedUnitLabel.setBounds(dumpedUnitLabel_Left, dumpedUnitLabel_Top, dumpedUnitLabel_W, dumpedUnitLabel_H);
        dumpedUnitLabel.setFont(myFont4);
        dumpedUnitLabel.setForeground(Color.decode(color_White_1));
 

        //DUMPED 0 LABEL DEFINE
        dumped0Label = new JLabel("0", JLabel.CENTER);
        dumped0Label.setBounds(dumped0Label_Left, dumped0Label_Top, dumped0Label_W, dumped0Label_H);
        dumped0Label.setFont(myFont4);
        dumped0Label.setForeground(Color.decode(color_White_1));

        //TOTAL DATA SIZE LABEL DEFINE
        totalSizeLabel = new JLabel("100", JLabel.CENTER);
        totalSizeLabel.setBounds(totalSizeLabel_Left, totalSizeLabel_Top, totalSizeLabel_W, totalSizeLabel_H);
        totalSizeLabel.setFont(myFont4);
        totalSizeLabel.setForeground(Color.decode(color_White_1));


        //TIME REMAIN BAR LABEL DEFINE
        timeRemainBarLabel = new JLabel(timeRemain_0_Icon);
        timeRemainBarLabel.setLayout(null);
        timeRemainBarLabel.setBounds(timeRemainBarLabel_Left, timeRemainBarLabel_Top, timeRemainBarLabel_W, timeRemainBarLabel_H);
        timeRemainBarLabel.setBackground(new Color(0,0,0,0));


        //TIME REMAIN NUM LABEL DEFINE
        timeRemainNumLabel = new JLabel("2", JLabel.CENTER);
        timeRemainNumLabel.setBounds(timeRemainNumLabel_Left, timeRemainNumLabel_Top, timeRemainNumLabel_W, timeRemainNumLabel_H);
        timeRemainNumLabel.setFont(myFont3);
        timeRemainNumLabel.setForeground(Color.decode(color_White_1));


        //TIME UNIT LABEL DEFINE
        timeUnitLabel = new JLabel("Second", JLabel.CENTER);
        timeUnitLabel.setBounds(timeUnitLabel_Left, timeUnitLabel_Top, timeUnitLabel_W, timeUnitLabel_H);
        timeUnitLabel.setFont(myFont3);
        timeUnitLabel.setForeground(Color.decode(color_White_1));


        //TOTAL TIME LABEL DEFINE
        totalTimeLabel = new JLabel("1.25 Minutes", JLabel.CENTER);
        totalTimeLabel.setBounds(totaltimeLabel_Left, totaltimeLabel_Top, totaltimeLabel_W, totaltimeLabel_H);
        totalTimeLabel.setFont(myFont2);
        totalTimeLabel.setForeground(Color.decode(color_White_1));

        //TIME 0 LABEL DEFINE
        time0Label = new JLabel("0", JLabel.CENTER);
        time0Label.setBounds(time0Label_Left, time0Label_Top, time0Label_W, time0Label_H);
        time0Label.setFont(myFont2);
        time0Label.setForeground(Color.decode(color_White_1));

        //BAR TOP NAME LABEL DEFINE
        barTopLabel = new JLabel("         Dumped                 Dump                  Time", JLabel.LEFT);
        barTopLabel.setBounds(barTopLabel_Left, barTopLabel_Top, barTopLabel_W, barTopLabel_H);
        barTopLabel.setFont(myFont3);
        barTopLabel.setForeground(Color.decode(color_White_1));


        //BAR BOTTOM NAME LABEL DEFINE
        barBottomLabel = new JLabel("            Data                   Speed                Remain", JLabel.LEFT);
        //barBottomLabel.setBounds(barBottomLabel_Left, barBottomLabel_Top, barBottomLabel_H, barBottomLabel_W);
        barBottomLabel.setBounds(barBottomLabel_Left, barBottomLabel_Top, barBottomLabel_W, barBottomLabel_H);
        barBottomLabel.setFont(myFont3);
        barBottomLabel.setForeground(Color.decode(color_White_1));

        //INFO TEXT AREA DEFINE
        infoTextArea = new JTextArea();
        infoTextArea.setBounds(infoTextArea_Left, infoTextArea_Top, infoTextArea_W, infoTextArea_H);
        infoTextArea.setForeground(Color.decode(color_White_1));
        infoTextArea.setBackground(new Color(0,0,0,0));
        infoTextArea.setFont(myFont4);
        infoTextArea.append("\n       DUMP INFO\n");
        infoTextArea.append("\n Addr : ");
        infoTextArea.append("\n Size : ");
        infoTextArea.append("\n Part Name : ");
        infoTextArea.append("\n Data_Output_0.prn\n");
        infoTextArea.append("\n      Part No\n");
        //infoTextArea.setFont(myFont);
        infoTextArea.append("\n       1/24");


        //BUTTON DEFINE
        pauseButton = new JButton(pause_Button_Icon);
        pauseButton.setBounds(pauseButton_Left, pauseButton_Top, pauseButton_W, pauseButton_H);
        pauseButton.setFont(myFont3);
        pauseButton.setBackground(Color.decode(color_darkMode_1));
        pauseButton.setForeground(Color.decode(color_White_1));
        pauseButton.setBorder(null);
        pauseButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {pauseButton.setIcon(pause_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {pauseButton.setIcon(pause_Button_Icon);}});


        continueButton = new JButton(continue_Button_Icon);
        continueButton.setBounds(pauseButton_Left, pauseButton_Top, pauseButton_W, pauseButton_H);
        continueButton.setFont(myFont3);
        continueButton.setBackground(Color.decode(color_darkMode_1));
        continueButton.setForeground(Color.decode(color_White_1));
        continueButton.setBorder(null);
        continueButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {continueButton.setIcon(continue_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {continueButton.setIcon(continue_Button_Icon);}});


        stopButton = new JButton(stop_Button_Icon);
        stopButton.setBounds(stopButton_Left, stopButton_Top, stopButton_W, stopButton_H);
        stopButton.setFont(myFont3);
        stopButton.setBackground(Color.decode(color_darkMode_1));
        stopButton.setForeground(Color.decode(color_White_1));
        stopButton.setBorder(null);
        stopButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {stopButton.setIcon(stop_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {stopButton.setIcon(stop_Button_Icon);}});



        //PAUSE PANEL ADD COMPONENT
        pausePanel.add(pauseButton);
        continuePanel.add(continueButton);


        //LOADING MAIN PANEL ADD COMPONENT
        loadingMainPanel.add(pleaseWaitLabel);

        loadingMainPanel.add(progressNumLabel);
        loadingMainPanel.add(progressBarLabel);
        loadingMainPanel.add(progressLabel);
        
        loadingMainPanel.add(dumpSpeedMaxLabel);
        loadingMainPanel.add(dumpSpeedBarLabel);
        loadingMainPanel.add(dumpSpeedNumLabel);
        loadingMainPanel.add(dumpSpeedUnitLabel);

        loadingMainPanel.add(dumped0Label);
        loadingMainPanel.add(totalSizeLabel);
        loadingMainPanel.add(dumpedBarLabel);
        loadingMainPanel.add(dumpedNumLabel);
        loadingMainPanel.add(dumpedUnitLabel);

        loadingMainPanel.add(time0Label);
        loadingMainPanel.add(totalTimeLabel);
        loadingMainPanel.add(timeRemainBarLabel);
        loadingMainPanel.add(timeRemainNumLabel);
        loadingMainPanel.add(timeUnitLabel);

        loadingMainPanel.add(barTopLabel);
        loadingMainPanel.add(barBottomLabel);

        loadingMainPanel.add(infoTextArea);

        
        loadingMainPanel.add(pausePanel);
        loadingMainPanel.add(continuePanel);
        
        loadingMainPanel.add(stopButton);

        loadingMainPanel.add(backgroundLabel);


        //progressSimulation();

    }

}
