package gui.menuWindow;

import javax.swing.*;
import java.awt.*;

public class MenuWindow {

    //WINDOW ATTRIBUTE DECLARATION
    public JPanel menuTopPanel, menuDropDownPanel;
    public JButton menuButton, prnDumpButton, rgbDumpButton, codecDump_1_Button, codecDump_2_Button, customDumpButton;
    public JLabel menuDropDownBackground;

    //UI ATTRIBUTE DIMENSION AND LAYOUT

    //MENU TOP PANEL;
    int menuTopPanel_W = 70;
    int menuTopPanel_H = 70;
    int menuTopPanel_Left = 0;
    int menuTopPanel_Top = 0;

    //MENU DROP DOWN PANEL;
    int menuDropDownPanel_W = 235;
    int menuDropDownPanel_H = 320;
    int menuDropDownPanel_Left = 13;
    int menuDropDownPanel_Top = 51;

    //MENU DROP DOWN BACKGROUND;
    int menuDropDownBackground_W = menuDropDownPanel_W;
    int menuDropDownBackground_H = menuDropDownPanel_H;
    int menuDropDownBackground_Left = 0;
    int menuDropDownBackground_Top = 0;

    //MENU BUTTON
    int menuButton_W = 30;
    int menuButton_H = 32;
    int menuButton_Left = 20;
    int menuButton_Top = 19;

    //PRN DUMP BUTTON
    int prnDumpButton_W = 174;
    int prnDumpButton_H = 32;
    int prnDumpButton_Left = 7;
    int prnDumpButton_Top = 1;

    //RGB DUMP BUTTON
    int rgbDumpButton_W = prnDumpButton_W;
    int rgbDumpButton_H = prnDumpButton_H;
    int rgbDumpButton_Left = prnDumpButton_Left;
    int rgbDumpButton_Top = prnDumpButton_Top + prnDumpButton_H;

    //CODEC 1 DUMP BUTTON
    int codecDump_1_ButtonButton_W = prnDumpButton_W;
    int codecDump_1_ButtonButton_H = prnDumpButton_H;
    int codecDump_1_ButtonButton_Left = prnDumpButton_Left;
    int codecDump_1_ButtonButton_Top = rgbDumpButton_Top + rgbDumpButton_H;

    //CODEC 2 DUMP BUTTON
    int codecDump_2_ButtonButton_W = prnDumpButton_W;
    int codecDump_2_ButtonButton_H = prnDumpButton_H;
    int codecDump_2_ButtonButton_Left = prnDumpButton_Left;
    int codecDump_2_ButtonButton_Top = codecDump_1_ButtonButton_Top + codecDump_1_ButtonButton_H;

    //CUSTOM DUMP BUTTON
    int customDumpButtonButton_W = prnDumpButton_W;
    int customDumpButtonButton_H = prnDumpButton_H;
    int customDumpButtonButton_Left = prnDumpButton_Left;
    int customDumpButtonButton_Top = codecDump_2_ButtonButton_Top + codecDump_2_ButtonButton_H;


    //COLOR DEFINITION
    String color_darkMode_1     = "#23242C";
    String color_darkMode_2     = "#383B4F";
    String color_White_1        = "#F1F3F4";
    String color_greenBlue_1    = "#03DAC5";
    String color_magenta_1      = "#FF4A84";

    //FONT DEFINITION
    Font myFont = new Font("Verdana",Font.PLAIN, 16);
    Font myFont2 = new Font("Verdana",Font.PLAIN, 12);
    Font myFont3 = new Font("Verdana",Font.PLAIN, 14);
    Font myFont4 = new Font("Verdana",Font.PLAIN, 10);

    //ICON DEVINITION
    String userDirectory = System.getProperty("user.dir");

    Icon Menu_Button_Icon           = new ImageIcon(userDirectory+"\\lib\\gui\\menuWindow\\icons\\Menu_Button.png");
    Icon Menu_Button_Icon2          = new ImageIcon(userDirectory+"\\lib\\gui\\menuWindow\\icons\\Menu_Button2.png");

    Icon Menu_DropDown_Background   = new ImageIcon(userDirectory+"\\lib\\gui\\menuWindow\\icons\\Menu_Background.png");

    Icon PRN_Dump_Button_Icon       = new ImageIcon(userDirectory+"\\lib\\gui\\menuWindow\\icons\\Raster_PRN_Dump_Button.png");
    Icon PRN_Dump_Button_Icon2      = new ImageIcon(userDirectory+"\\lib\\gui\\menuWindow\\icons\\Raster_PRN_Dump_Button2.png");

    Icon RGB_Dump_Button_Icon       = new ImageIcon(userDirectory+"\\lib\\gui\\menuWindow\\icons\\RGB_Data_Dump_Button.png");
    Icon RGB_Dump_Button_Icon2      = new ImageIcon(userDirectory+"\\lib\\gui\\menuWindow\\icons\\RGB_Data_Dump_Button2.png");

    Icon Codec1_Dump_Button_Icon    = new ImageIcon(userDirectory+"\\lib\\gui\\menuWindow\\icons\\Codec_Output_Dump_Button.png");
    Icon Codec1_Dump_Button_Icon2   = new ImageIcon(userDirectory+"\\lib\\gui\\menuWindow\\icons\\Codec_Output_Dump_Button2.png");

    Icon Codec2_Dump_Button_Icon    = new ImageIcon(userDirectory+"\\lib\\gui\\menuWindow\\icons\\Codec_Apf_Dump_Button.png");
    Icon Codec2_Dump_Button_Icon2   = new ImageIcon(userDirectory+"\\lib\\gui\\menuWindow\\icons\\Codec_Apf_Dump_Button2.png");

    Icon Custom_Dump_Button_Icon    = new ImageIcon(userDirectory+"\\lib\\gui\\menuWindow\\icons\\Custom_Dump_Button.png");
    Icon Custom_Dump_Button_Icon2   = new ImageIcon(userDirectory+"\\lib\\gui\\menuWindow\\icons\\Custom_Dump_Button2.png");



    //CONSTRUCTOR
    public MenuWindow(){

        //PANEL DEFINE
        menuTopPanel = new JPanel();
        menuTopPanel.setLayout(null);
        menuTopPanel.setBounds(menuTopPanel_Left, menuTopPanel_Top, menuTopPanel_W, menuTopPanel_H);
        //menuTopPanel.setBackground(Color.decode(color_darkMode_1));
        menuTopPanel.setBackground(new Color(0,0,0,0));


        menuDropDownPanel = new JPanel();
        menuDropDownPanel.setLayout(null);
        menuDropDownPanel.setBounds(menuDropDownPanel_Left, menuDropDownPanel_Top, menuDropDownPanel_W, menuDropDownPanel_H);
        menuDropDownPanel.setBackground(new Color(0,0,0,0));

        //BACKGROUND DEFINE
        menuDropDownBackground = new JLabel(Menu_DropDown_Background);
        menuDropDownBackground.setLayout(null);
        menuDropDownBackground.setBounds(menuDropDownBackground_Left, menuDropDownBackground_Top, menuDropDownBackground_W, menuDropDownBackground_H);
        menuDropDownBackground.setBackground(new Color(0,0,0,0));
        //menuTopPanel.setBackground(Color.decode(color_darkMode_1));


        //BUTTON DEFINE
        menuButton = new JButton(Menu_Button_Icon);
        menuButton.setBounds(menuButton_Left, menuButton_Top, menuButton_W, menuButton_H);
        menuButton.setFont(myFont2);
        menuButton.setBackground(Color.decode(color_darkMode_1));
        menuButton.setForeground(Color.decode(color_White_1));
        menuButton.setBorder(null);
        menuButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {menuButton.setIcon(Menu_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {menuButton.setIcon(Menu_Button_Icon);}});

        prnDumpButton = new JButton(PRN_Dump_Button_Icon);
        prnDumpButton.setBounds(prnDumpButton_Left, prnDumpButton_Top, prnDumpButton_W, prnDumpButton_H);
        prnDumpButton.setFont(myFont2);
        prnDumpButton.setBackground(Color.decode(color_darkMode_1));
        prnDumpButton.setForeground(Color.decode(color_White_1));
        prnDumpButton.setBorder(null);
        prnDumpButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {prnDumpButton.setIcon(PRN_Dump_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {prnDumpButton.setIcon(PRN_Dump_Button_Icon);}});

        rgbDumpButton = new JButton(RGB_Dump_Button_Icon);
        rgbDumpButton.setBounds(rgbDumpButton_Left, rgbDumpButton_Top, rgbDumpButton_W, rgbDumpButton_H);
        rgbDumpButton.setFont(myFont2);
        rgbDumpButton.setBackground(Color.decode(color_darkMode_1));
        rgbDumpButton.setForeground(Color.decode(color_White_1));
        rgbDumpButton.setBorder(null);
        rgbDumpButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {rgbDumpButton.setIcon(RGB_Dump_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {rgbDumpButton.setIcon(RGB_Dump_Button_Icon);}});

        codecDump_1_Button = new JButton(Codec1_Dump_Button_Icon);
        codecDump_1_Button.setBounds(codecDump_1_ButtonButton_Left, codecDump_1_ButtonButton_Top, codecDump_1_ButtonButton_W, codecDump_1_ButtonButton_H);
        codecDump_1_Button.setFont(myFont2);
        codecDump_1_Button.setBackground(Color.decode(color_darkMode_1));
        codecDump_1_Button.setForeground(Color.decode(color_White_1));
        codecDump_1_Button.setBorder(null);
        codecDump_1_Button.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {codecDump_1_Button.setIcon(Codec1_Dump_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {codecDump_1_Button.setIcon(Codec1_Dump_Button_Icon);}});

        codecDump_2_Button = new JButton(Codec2_Dump_Button_Icon);
        codecDump_2_Button.setBounds(codecDump_2_ButtonButton_Left, codecDump_2_ButtonButton_Top, codecDump_2_ButtonButton_W, codecDump_2_ButtonButton_H);
        codecDump_2_Button.setFont(myFont2);
        codecDump_2_Button.setBackground(Color.decode(color_darkMode_1));
        codecDump_2_Button.setForeground(Color.decode(color_White_1));
        codecDump_2_Button.setBorder(null);
        codecDump_2_Button.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {codecDump_2_Button.setIcon(Codec2_Dump_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {codecDump_2_Button.setIcon(Codec2_Dump_Button_Icon);}});

        customDumpButton = new JButton(Custom_Dump_Button_Icon);
        customDumpButton.setBounds(customDumpButtonButton_Left, customDumpButtonButton_Top, customDumpButtonButton_W, customDumpButtonButton_H);
        customDumpButton.setFont(myFont2);
        customDumpButton.setBackground(Color.decode(color_darkMode_1));
        customDumpButton.setForeground(Color.decode(color_White_1));
        customDumpButton.setBorder(null);
        customDumpButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {customDumpButton.setIcon(Custom_Dump_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {customDumpButton.setIcon(Custom_Dump_Button_Icon);}});


        //MENU TOP PANEL ADD COMPONENT
        menuTopPanel.add(menuButton);

        //MENU DROP DOWN ADD COMPONEN
        menuDropDownPanel.add(prnDumpButton);
        menuDropDownPanel.add(rgbDumpButton);
        menuDropDownPanel.add(codecDump_1_Button);
        menuDropDownPanel.add(codecDump_2_Button);
        menuDropDownPanel.add(customDumpButton);
        menuDropDownPanel.add(menuDropDownBackground);

        //SET VISIBLE
        menuTopPanel.setVisible(true);
        menuDropDownPanel.setVisible(true);
        
    }

}
