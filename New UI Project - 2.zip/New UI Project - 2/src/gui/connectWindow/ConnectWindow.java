package gui.connectWindow;

import javax.swing.*;
import java.awt.*;

public class ConnectWindow {

    //WINDOW ATTRIBUTE DECLARATION
    public JPanel connectPanel, disconnectPanel;
    public JButton connectButton, disconnectButton;

    //UI ATTRIBUTE DIMENSION AND LAYOUT

    //CONNECT PANEL;
    int connectPanel_W = 430;
    int connectPanel_H = 40;
    int connectPanel_Left = 0;
    int connectPanel_Top = 170;

    //DISCONNECT PANEL;
    int disconnectPanel_W = connectPanel_W;
    int disconnectPanel_H = connectPanel_H;
    int disconnectPanel_Left = connectPanel_Left;
    int disconnectPanel_Top = connectPanel_Top;

    //CONNECT BUTTON
    int connectButton_W = 125;
    int connectButton_H = 40;
    int connectButton_Left = (connectPanel_W/2) - (connectButton_W/2);
    int connectButton_Top = 0;

    int disconnectButton_W = connectButton_W;
    int disconnectButton_H = connectButton_H;
    int disconnectButton_Left = connectButton_Left;
    int disconnectButton_Top = connectButton_Top;


    //COLOR DEFINITION
    String color_darkMode_1     = "#23242C";
    String color_darkMode_2     = "#383B4F";
    String color_White_1        = "#F1F3F4";
    String color_greenBlue_1    = "#03DAC5";
    String color_magenta_1      = "#FF4A84";

    //FONT DEFINITION
    Font myFont = new Font("Verdana",Font.PLAIN, 16);
    Font myFont2 = new Font("Verdana",Font.PLAIN, 14);
    Font myFont3 = new Font("Verdana",Font.PLAIN, 12);
    Font myFont4 = new Font("Verdana",Font.PLAIN, 10);

    //ICON DEVINITION
    String userDirectory = System.getProperty("user.dir");

    Icon Connect_Button_Icon    = new ImageIcon(userDirectory+"\\lib\\gui\\connectWindow\\icons\\Connect_Button.png");
    Icon Connect_Button_Icon2   = new ImageIcon(userDirectory+"\\lib\\gui\\connectWindow\\icons\\Connect_Button2.png");

    Icon Disonnect_Button_Icon  = new ImageIcon(userDirectory+"\\lib\\gui\\connectWindow\\icons\\Disconnect_Button.png");
    Icon Disonnect_Button_Icon2 = new ImageIcon(userDirectory+"\\lib\\gui\\connectWindow\\icons\\Disconnect_Button2.png");



    //CONSTRUCTOR
    public ConnectWindow(){

        //PANEL DEFINE
        connectPanel = new JPanel();
        connectPanel.setLayout(null);
        connectPanel.setBounds(connectPanel_Left, connectPanel_Top, connectPanel_W, connectPanel_H);
        connectPanel.setBackground(Color.decode(color_darkMode_2));

        disconnectPanel = new JPanel();
        disconnectPanel.setLayout(null);
        disconnectPanel.setBounds(disconnectPanel_Left, disconnectPanel_Top, disconnectPanel_W, disconnectPanel_H);
        disconnectPanel.setBackground(Color.decode(color_darkMode_2));


        //BUTTON DEFINE
        connectButton = new JButton(Connect_Button_Icon);
        connectButton.setBounds(connectButton_Left, connectButton_Top, connectButton_W, connectButton_H);
        connectButton.setFont(myFont2);
        connectButton.setBackground(Color.decode(color_darkMode_2));
        connectButton.setForeground(Color.decode(color_White_1));
        connectButton.setBorder(null);
        connectButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {connectButton.setIcon(Connect_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {connectButton.setIcon(Connect_Button_Icon);}});

        disconnectButton = new JButton(Disonnect_Button_Icon);
        disconnectButton.setBounds(disconnectButton_Left, disconnectButton_Top, disconnectButton_W, disconnectButton_H);
        disconnectButton.setFont(myFont2);
        disconnectButton.setBackground(Color.decode(color_darkMode_2));
        disconnectButton.setForeground(Color.decode(color_White_1));
        disconnectButton.setBorder(null);
        disconnectButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {disconnectButton.setIcon(Disonnect_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {disconnectButton.setIcon(Disonnect_Button_Icon);}});


        //CONNECT PANEL ADD COMPONENT
        connectPanel.add(connectButton);

        //DISCONNECT PANEL ADD COMPONENT
        disconnectPanel.add(disconnectButton);

        //SET VISIBLE
        connectPanel.setVisible(true);
        disconnectPanel.setVisible(true);
    }

}
