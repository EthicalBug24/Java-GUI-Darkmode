package gui.mainWindow;

import javax.swing.*;
import java.awt.*;

public class MainWindow {

    //WINDOW ATTRIBUTE DECLARATION
    //JFrame frame;
    public JPanel headerPanel, mainPanel;
    public JLabel headerLabel, printerNameLabel, rCodeLabel, mapTxtLabel, addressLabel, sizeLabel, statusLabel;
    public JTextField printerNameTextField, rCodeTextField, mapTxtTextField, addressTextField, sizeTextField;
    public JButton getButton, searchButton, browseButton, refreshButton, startDumpButton;
    public JTextArea statusBox;


    //UI ATTRIBUTE DIMENSION AND LAYOUT
    //FRAME
    int frame_W = 430;
    int frame_H = 620;

    //MARGIN
    int leftMargin = 20;
    int gapVertical = 10;

    //HEADER PANEL;
    int headerPanel_W = frame_W;
    int headerPanel_H = 70;

    //MAIN PANEL;
    int mainPanel_W = frame_W;
    int mainPanel_H = frame_H-headerPanel_H;


    //HEADER LABEL
    int headerLabel_W = frame_W;
    int headerLabel_H = headerPanel_H;

    //PRINTER NAME LABEL
    int printerNameLabel_W = 70;
    int printerNameLabel_H = 30;
    int printerLabel_Top = gapVertical+10;

    //R CODE LABEL
    int rCodeLabel_W = printerNameLabel_W;
    int rCodeLabel_H = printerNameLabel_H;
    int rCodeLabel_Top = printerLabel_Top + printerNameLabel_H + gapVertical;

    //MAP TXT LABEL
    int mapTxtLabel_W = rCodeLabel_W;
    int mapTxtLabel_H = rCodeLabel_H;
    int mapTxtLabel_Top = rCodeLabel_Top + rCodeLabel_H + gapVertical + rCodeLabel_H + 10 + gapVertical + 30;

    //ADDRESS LABEL
    int addressLabel_W = 130;
    int addressLabel_H = mapTxtLabel_H;
    int addressLabel_Top = mapTxtLabel_Top + rCodeLabel_H + gapVertical;

    //SIZE LABEL
    int sizeLabel_W = addressLabel_W;
    int sizeLabel_H = addressLabel_H;
    int sizeLabel_Top = addressLabel_Top;
    int sizeLabel_Left = leftMargin + addressLabel_W + 10;

    //STATUS LABEL
    int statusLabel_W = addressLabel_W;
    int statusLabel_H = addressLabel_H;
    int statusLabel_Top = sizeLabel_Top + 120;
    int statusLabel_Left = leftMargin;


    //PRINTER NAME TEXT FIELD
    int printerNameTextField_W =200;
    int printerNameTextField_H = printerNameLabel_H;
    int printerNameTextField_Left = leftMargin + printerNameLabel_W;
    int printerNameTextField_Top = printerLabel_Top;

    //R CODE TEXT FILED
    int rCodeTextField_W = printerNameTextField_W;
    int rCodeTextField_H = printerNameTextField_H;
    int rCodeTextField_Left = printerNameTextField_Left;
    int rCodeTextField_Top = rCodeLabel_Top;

    //MAP TXT TEXT FILED
    int mapTxtTextField_W = rCodeTextField_W;
    int mapTxtTextField_H = rCodeTextField_H;
    int mapTxtTextField_Left = rCodeTextField_Left;
    int mapTxtTextField_Top = mapTxtLabel_Top;

    //ADDRESS TEXT FILED
    int addressTextField_W = 130;
    int addressTextField_H = mapTxtTextField_H;
    int addressTextField_Left = leftMargin;
    int addressTextField_Top = addressLabel_Top + addressLabel_H;

    //SIZE TEXT FILED
    int sizeTextField_W = addressTextField_W;
    int sizeTextField_H = addressTextField_H;
    int sizeTextField_Left = addressTextField_Left + addressTextField_W + 10;
    int sizeTextField_Top = addressTextField_Top;


    //GET BUTTON
    int getButton_W = 95;
    int getButton_H = printerNameTextField_H;
    int getButton_Left = printerNameTextField_Left + printerNameTextField_W + 12;
    int getButton_Top = printerNameTextField_Top;

    //SEARCH BUTTON
    int searchButton_W = getButton_W;
    int searchButton_H = getButton_H;
    int searchButton_Left = getButton_Left;
    int searchButton_Top = rCodeTextField_Top;

    //SEARCH BUTTON
    int browseButton_W = getButton_W;
    int browseButton_H = getButton_H;
    int browseButton_Left = getButton_Left;
    int browseButton_Top = mapTxtTextField_Top;

    //REFRESH BUTTON
    int refreshButton_W = browseButton_W;
    int refreshButton_H = browseButton_H;
    int refreshButton_Left = browseButton_Left;
    int refreshButton_Top = sizeTextField_Top;

    //START DUMP BUTTON
    int startDumpButton_W = getButton_W+30;
    int startDumpButton_H = getButton_H+10;
    int startDumpButton_Left = (frame_W/2) - (startDumpButton_W/2);
    int startDumpButton_Top = refreshButton_Top + refreshButton_H + 20;

    //STATUS BOX TEXT AREA
    int statusBox_W = 377;
    int statusBox_H = 140;
    int statusBox_Left = leftMargin;
    int statusBox_Top = statusLabel_Top + statusLabel_H;


    //COLOR DEFINITION
    public String color_darkMode_1     = "#23242C";
    public String color_darkMode_2     = "#383B4F";
    public String color_darkMode_3     = "#242633";
    public String color_White_1        = "#F1F3F4";
    public String color_greenBlue_1    = "#03DAC5";
    public String color_magenta_1      = "#FF4A84";

    //FONT DEFINITION
    Font myFont = new Font("Nadeem",Font.PLAIN, 16);
    Font myFont2 = new Font("Verdana",Font.PLAIN, 14);
    Font myFont3 = new Font("Verdana",Font.PLAIN, 12);
    Font myFont4 = new Font("Verdana",Font.PLAIN, 10);

    //ICON DEVINITION

    String userDirectory = System.getProperty("user.dir");

    Icon Get_Button_Icon         = new ImageIcon(userDirectory+"\\lib\\gui\\mainWindow\\icons\\Get_Button.png");
    Icon Get_Button_Icon2        = new ImageIcon(userDirectory+"\\lib\\gui\\mainWindow\\icons\\Get_Button2.png");

    Icon Search_Button_Icon      = new ImageIcon(userDirectory+"\\lib\\gui\\mainWindow\\icons\\Search_Button.png");
    Icon Search_Button_Icon2     = new ImageIcon(userDirectory+"\\lib\\gui\\mainWindow\\icons\\Search_Button2.png");

    Icon Browse_Button_Icon      = new ImageIcon(userDirectory+"\\lib\\gui\\mainWindow\\icons\\Browse_Button.png");
    Icon Browse_Button_Icon2     = new ImageIcon(userDirectory+"\\lib\\gui\\mainWindow\\icons\\Browse_Button2.png");

    Icon Refresh_Button_Icon     = new ImageIcon(userDirectory+"\\lib\\gui\\mainWindow\\icons\\Refresh_Button.png");
    Icon Refresh_Button_Icon2    = new ImageIcon(userDirectory+"\\lib\\gui\\mainWindow\\icons\\Refresh_Button2.png");

    Icon StartDump_Button_Icon   = new ImageIcon(userDirectory+"\\lib\\gui\\mainWindow\\icons\\StartDump_Button.png");
    Icon StartDump_Button_Icon2  = new ImageIcon(userDirectory+"\\lib\\gui\\mainWindow\\icons\\StartDump_Button2.png");






    //CONSTRUCTOR
    public MainWindow(){
        System.out.println(userDirectory);

        //PANEL DEFINE
        headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBounds(0, 0, headerPanel_W, headerPanel_H);
        headerPanel.setBackground(Color.decode(color_darkMode_1));

        mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBounds(0, headerPanel_H, mainPanel_W, mainPanel_H);
        mainPanel.setBackground(Color.decode(color_darkMode_2));

        //LABEL DEFINE
        headerLabel = new JLabel("IMAGE PROCESSING PRN DUMP", JLabel.CENTER);
        headerLabel.setBounds(0, 0, headerLabel_W, headerLabel_H);
        headerLabel.setFont(myFont);
        headerLabel.setForeground(Color.decode(color_White_1));

        printerNameLabel = new JLabel("Printer", JLabel.LEFT);
        printerNameLabel.setBounds(leftMargin, printerLabel_Top, printerNameLabel_W, printerNameLabel_H);
        printerNameLabel.setFont(myFont2);
        printerNameLabel.setForeground(Color.decode(color_White_1));

        rCodeLabel = new JLabel("R Code", JLabel.LEFT);
        rCodeLabel.setBounds(leftMargin, rCodeLabel_Top, rCodeLabel_W, rCodeLabel_H);
        rCodeLabel.setFont(myFont2);
        rCodeLabel.setForeground(Color.decode(color_White_1));

        mapTxtLabel = new JLabel("Map.txt", JLabel.LEFT);
        mapTxtLabel.setBounds(leftMargin, mapTxtLabel_Top, mapTxtLabel_W, mapTxtLabel_H);
        mapTxtLabel.setFont(myFont2);
        mapTxtLabel.setForeground(Color.decode(color_White_1));

        addressLabel = new JLabel("Address", JLabel.LEFT);
        addressLabel.setBounds(leftMargin, addressLabel_Top, addressLabel_W, addressLabel_H);
        addressLabel.setFont(myFont2);
        addressLabel.setForeground(Color.decode(color_White_1));

        sizeLabel = new JLabel("Size (Byte)", JLabel.LEFT);
        sizeLabel.setBounds(sizeLabel_Left, sizeLabel_Top, sizeLabel_W, sizeLabel_H);
        sizeLabel.setFont(myFont2);
        sizeLabel.setForeground(Color.decode(color_White_1));

        statusLabel = new JLabel("Status", JLabel.LEFT);
        statusLabel.setBounds(statusLabel_Left, statusLabel_Top, statusLabel_W, statusLabel_H);
        statusLabel.setFont(myFont2);
        statusLabel.setForeground(Color.decode(color_White_1));


        //TEXT FIELD DEFINE
        printerNameTextField = new JTextField(0);
        printerNameTextField.setBounds(printerNameTextField_Left, printerNameTextField_Top, printerNameTextField_W, printerNameTextField_H);
        printerNameTextField.setFont(myFont2);
        printerNameTextField.setBackground(Color.decode(color_darkMode_1));
        printerNameTextField.setForeground(Color.decode(color_White_1));
        printerNameTextField.setBorder(null);

        rCodeTextField = new JTextField(0);
        rCodeTextField.setBounds(rCodeTextField_Left, rCodeTextField_Top, rCodeTextField_W, rCodeTextField_H);
        rCodeTextField.setFont(myFont2);
        rCodeTextField.setBackground(Color.decode(color_darkMode_1));
        rCodeTextField.setForeground(Color.decode(color_White_1));
        rCodeTextField.setBorder(null);

        mapTxtTextField = new JTextField(0);
        mapTxtTextField.setBounds(mapTxtTextField_Left, mapTxtTextField_Top, mapTxtTextField_W, mapTxtTextField_H);
        mapTxtTextField.setFont(myFont2);
        mapTxtTextField.setBackground(Color.decode(color_darkMode_1));
        mapTxtTextField.setForeground(Color.decode(color_White_1));
        mapTxtTextField.setBorder(null);

        addressTextField = new JTextField(0);
        addressTextField.setBounds(leftMargin, addressTextField_Top, addressTextField_W, addressTextField_H);
        addressTextField.setFont(myFont2);
        addressTextField.setBackground(Color.decode(color_darkMode_1));
        addressTextField.setForeground(Color.decode(color_White_1));
        addressTextField.setBorder(null);

        sizeTextField = new JTextField(0);
        sizeTextField.setBounds(sizeTextField_Left, sizeTextField_Top, sizeTextField_W, sizeTextField_H);
        sizeTextField.setFont(myFont2);
        sizeTextField.setBackground(Color.decode(color_darkMode_1));
        sizeTextField.setForeground(Color.decode(color_White_1));
        sizeTextField.setBorder(null);



        //BUTTON DEFINE
        getButton = new JButton(Get_Button_Icon);
        getButton.setBounds(getButton_Left, getButton_Top, getButton_W, getButton_H);
        getButton.setFont(myFont3);
        getButton.setBackground(Color.decode(color_darkMode_2));
        getButton.setForeground(Color.decode(color_White_1));
        getButton.setBorder(null);
        getButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {getButton.setIcon(Get_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {getButton.setIcon(Get_Button_Icon);}});

        searchButton = new JButton(Search_Button_Icon);
        searchButton.setBounds(searchButton_Left, searchButton_Top, searchButton_W, searchButton_H);
        searchButton.setFont(myFont3);
        searchButton.setBackground(Color.decode(color_darkMode_2));
        searchButton.setForeground(Color.decode(color_White_1));
        searchButton.setBorder(null);
        searchButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {searchButton.setIcon(Search_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {searchButton.setIcon(Search_Button_Icon);}});

        browseButton = new JButton(Browse_Button_Icon);
        browseButton.setBounds(browseButton_Left, browseButton_Top, browseButton_W, browseButton_H);
        browseButton.setFont(myFont2);
        browseButton.setBackground(Color.decode(color_darkMode_2));
        browseButton.setForeground(Color.decode(color_White_1));
        browseButton.setBorder(null);
        browseButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {browseButton.setIcon(Browse_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {browseButton.setIcon(Browse_Button_Icon);}});

        refreshButton = new JButton(Refresh_Button_Icon);
        refreshButton.setBounds(refreshButton_Left, refreshButton_Top, refreshButton_W, refreshButton_H);
        refreshButton.setFont(myFont2);
        refreshButton.setBackground(Color.decode(color_darkMode_2));
        refreshButton.setForeground(Color.decode(color_White_1));
        refreshButton.setBorder(null);
        refreshButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {refreshButton.setIcon(Refresh_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {refreshButton.setIcon(Refresh_Button_Icon);}});
    

        startDumpButton = new JButton(StartDump_Button_Icon);
        startDumpButton.setBounds(startDumpButton_Left, startDumpButton_Top, startDumpButton_W, startDumpButton_H);
        startDumpButton.setFont(myFont2);
        startDumpButton.setBackground(Color.decode(color_darkMode_2));
        startDumpButton.setForeground(Color.decode(color_White_1));
        startDumpButton.setBorder(null);
        startDumpButton.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {startDumpButton.setIcon(StartDump_Button_Icon2);}
        public void mouseExited(java.awt.event.MouseEvent evt) {startDumpButton.setIcon(StartDump_Button_Icon);}});


        //STATUS BOX TEXT AREA DEFINE
        statusBox = new JTextArea();
        statusBox.setBounds(statusBox_Left, statusBox_Top, statusBox_W, statusBox_H);
        statusBox.setFont(myFont2);
        statusBox.setBackground(Color.decode(color_darkMode_2));
        statusBox.setForeground(Color.decode(color_White_1));
        statusBox.setBorder(BorderFactory.createLineBorder(Color.decode(color_magenta_1)));


        //PANEL HEADER ADD COMPONENT
        headerPanel.add(headerLabel);

        //MAIN PANEL ADD COMPONENT
        mainPanel.add(printerNameLabel);
        mainPanel.add(printerNameTextField);
        mainPanel.add(getButton);
        mainPanel.add(rCodeLabel);
        mainPanel.add(rCodeTextField);
        mainPanel.add(searchButton);
        //mainPanel.add(connectButton);
        mainPanel.add(mapTxtLabel);
        mainPanel.add(mapTxtTextField);
        mainPanel.add(browseButton);
        mainPanel.add(addressLabel);
        mainPanel.add(addressTextField);
        mainPanel.add(sizeLabel);
        mainPanel.add(sizeTextField);
        mainPanel.add(refreshButton);
        mainPanel.add(startDumpButton);
        mainPanel.add(statusLabel);
        mainPanel.add(statusBox);

        //FRAME ADD COMPONEN
        //frame.add(headerPanel);
        //frame.add(mainPanel);
//
        ////SET VISIBLE
        //frame.setVisible(true);
    }

}
