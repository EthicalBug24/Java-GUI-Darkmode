package appli;

import javax.swing.*;

import controller.prnDumpController;

import java.awt.event.*;
import gui.menuWindow.*;

public class appli implements ActionListener{

    //OTHER CLASS
    MenuWindow menuWindow = new MenuWindow();
    prnDumpController prnDumpAppli = new prnDumpController();

    //WINDOW ATTRIBUTE DECLARATION
    JFrame frame;

    //UI ATTRIBUTE DIMENSION AND LAYOUT
    //FRAME
    int frame_W = 430;
    int frame_H = 640;

    //GLOBAL VARIABLE
    int menuWindowLevel = 0;


    //CONSTRUCTOR
    public appli(){
        //FRAME DEFINE
        frame = new JFrame("Printing Data Analyzer");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(frame_W, frame_H);
        frame.setLayout(null);

        //FRAME ADD COMPONEN
        frame.add(menuWindow.menuDropDownPanel);
        frame.add(menuWindow.menuTopPanel);
        frame.add(prnDumpAppli.prnDumpPanel);

        //SET ACTION LISTENER
        menuWindow.menuButton.addActionListener(this);
        menuWindow.prnDumpButton.addActionListener(this);
        menuWindow.codecDump_1_Button.addActionListener(this);
        menuWindow.codecDump_2_Button.addActionListener(this);
        menuWindow.customDumpButton.addActionListener(this);

        
        //SET VISIBLE
        frame.setVisible(true);
        menuWindow.menuDropDownPanel.setVisible(false);
        menuWindow.menuTopPanel.setVisible(true);;
    }

    @Override
    public void actionPerformed(ActionEvent e){

        if(e.getSource() == menuWindow.menuButton){
            if (menuWindowLevel == 0){
                menuWindow.menuDropDownPanel.setVisible(true);
                menuWindowLevel ++ ;
            }
            else{
                menuWindow.menuDropDownPanel.setVisible(false);
                menuWindowLevel = 0;
            }
        }

        if(e.getSource() == menuWindow.prnDumpButton){
            prnDumpAppli.prnDumpPanel.setVisible(true);
            menuWindow.menuDropDownPanel.setVisible(false);
            menuWindowLevel = 0;
        }

    }
}
