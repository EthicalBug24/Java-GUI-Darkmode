import appli.*;

public class Main {
    public static void main(String[] args) {
        appli controller = new appli();
        String cwDir = System.getProperty("user.dir");
        System.out.println("Current Dir : " + cwDir);
    }
}
